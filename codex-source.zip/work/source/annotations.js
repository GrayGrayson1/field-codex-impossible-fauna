// Endpoints are fractions of the original painting, not of the responsive page.
// Each tuple: feature x/y, label placement x/y, optional clarified field note.
const plateCallouts = [
  [[.44,.17,0,.08,'Exhaust folds lie beneath the shoulder mantle.'],[.71,.49,1,.40,'Shock-absorbing vessels lie beneath the hindquarter.'],[.395,.923,0,.95]],
  [[.68,.19,1,.02],[.305,.355,0,.39],[.18,.49,0,.94]],
  [[.385,.18,0,.02],[.235,.515,0,.83],[.583,.481,1,.55]],
  [[.472,.167,0,.02],[.34,.40,0,.74],[.659,.048,1,.03]],
  [[.37,.48,0,.56,'A tuned air chamber lies beneath the breast.'],[.80,.76,1,.91],[.615,.414,1,.08]],
  [[.75,.70,1,.92,'Water pressure drives the root-like limbs.'],[.94,.26,1,.03],[.455,.17,0,.02]],
  [[.32,.32,0,.03,'The crown’s colony has no central brain.'],[.51,.42,1,.36],[.24,.20,0,.78]],
  [[.651,.402,1,.03],[.53,.18,0,.02],[.875,.49,1,.87,'Nested bone arches lie beneath the armored snout.']],
  [[.867,.133,1,.01],[.60,.52,1,.47],[.28,.50,0,.02,'Light-sensitive tissue lines the pale mantle.']],
  [[.71,.725,1,.95],[.342,.27,0,.03],[.475,.732,0,.85]],
  [[.574,.142,0,.04],[.751,.417,1,.55],[.738,.128,1,.01]],
  [[.465,.35,0,.03],[.883,.287,1,.02],[.665,.785,1,.94]],
  [[.819,.142,1,.02],[.534,.455,0,.61,'Charge tissue lies beneath the flank scales.'],[.838,.472,1,.88]],
  [[.662,.455,1,.52],[.538,.12,1,.01],[.239,.443,0,.07]],
  [[.60,.19,0,.02],[.738,.472,1,.42,'Mineral mortar binds the carried fragments.'],[.74,.755,1,.94,'Cushioned joints steady the carried structure.']],
  [[.471,.072,0,.02],[.518,.635,1,.66],[.60,.096,1,.02]],
  [[.601,.281,1,.03],[.32,.218,0,.01],[.347,.756,0,.96]],
  [[.711,.31,1,.04],[.49,.075,0,.01],[.355,.581,0,.64,'Hollow limb bones alter the chamber’s pitch.']],
  [[.743,.383,1,.03],[.39,.68,0,.41],[.386,.823,1,.94,'Ballast is sorted behind the broad throat.']],
  [[.60,.308,1,.32],[.596,.095,1,.01],[.57,.885,0,.94,'Broad feet spread the load across salt.']]
];
creatures.forEach((c,i)=>{
  c.callouts=plateCallouts[i].map(([x,y,lx,ly,note],j)=>({x,y,lx,ly}));
  c.annotations=c.annotations.map((note,j)=>plateCallouts[i][j][4]||note);
});

// Photo details identify visible surfaces; internal anatomy belongs to the drawn section.
const visibleStudyNames={1:['Shoulder mantle',null,'Traction-cleated hoof'],5:['Breast over air chamber',null,null],8:['Thermal seam',null,null],9:[null,null,'Sensory mantle'],11:[null,null,'Reflective eye'],12:['Insulating winter coat',null,null],14:['Fungal mantle',null,null],15:['Mineral-bound shell',null,null],17:['Reflective skin',null,null],19:[null,null,'Throat exterior']};
creatures.forEach(c=>{if(visibleStudyNames[c.id])c.anatomyStudies=c.anatomyStudies.map((s,j)=>visibleStudyNames[c.id][j]||s)});

const $=s=>document.querySelector(s), book=$('#book'), mobile=matchMedia('(max-width:767px), (max-width:999px) and (max-height:600px)'), reduced=matchMedia('(prefers-reduced-motion:reduce)');
const romans=['I','II','III','IV','V','VI'];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let state={entry:-2,side:0},busy=false,touch=null,toastTimer,finishTurn=null;
const paths={hoof:'M20 16v15c0 12 24 12 24 0V16M24 19v11c0 7 16 7 16 0V19M17 47h30M27 46v7m10-7v7',wing:'M31 31C8 6 8 34 27 34C4 50 30 55 32 36C36 58 57 48 37 34C61 33 53 7 33 30M32 19v31',crystal:'M12 42l9-24 12-8 10 12 10 22-21 10zM21 18l11 36 11-32M12 42l20-10 21 12M33 10l-1 22',bell:'M15 38c3-27 31-27 34 0zM21 39l-4 13m14-13v14m12-14 5 13M11 47V21m41 26V21',bone:'M13 20q17-14 20 10 6-20 21-12M13 20l16 16-5 13m10-18 14 15M29 25v22m-5 1h10',thorn:'M14 42l-3-18 12 8 9-21 10 20 12-7-4 19zM16 49h32',coral:'M32 50V15m0 23L18 24m14 17 15-17M18 24V13m0 11-8-6m37 6V13m0 11 8-6M25 49h14',ember:'M15 44l3-21 15-12 18 17-4 19-19 5zM33 19l-7 16 9-3-5 13',lamp:'M24 19h16l5 25H19zM27 13h10m-5 6V9M17 49h30M32 27v11',wind:'M10 26q10-16 27-7t16-6M10 36q14-15 32-2t12-7M11 46q13-11 30-3',shadow:'M20 12l9 12-8 7m16-20-6 19m0 7-7 16m10-17 9 14M14 36h9m15-7h13',snow:'M32 10v44M13 21l38 22M13 43l38-22M25 15l7 6 7-6M25 49l7-6 7 6',coil:'M45 22C27 1 8 31 27 40s26-7 18-14-21-4-15 5M40 14l-9 15h9L27 51',fungus:'M12 31c0-23 40-23 40 0zM27 32v19m10-19v19M21 51h22M19 25h.1M31 17h.1M43 26h.1',shell:'M11 39q21-45 42 0M15 43q17-35 34 0M20 47q12-23 24 0M14 50h36',quill:'M21 52q2-35 25-42 4 27-21 35M22 44l22-29M29 34l-1-11m7 4 10-2',mirror:'M11 26q21-20 42 0-21 20-42 0zM32 18a8 8 0 1 0 .1 0M12 42q10-8 20 0t20 0M14 50q9-7 18 0t18 0',sound:'M32 11a21 21 0 1 0 .1 0M32 19a13 13 0 1 0 .1 0M32 27a5 5 0 1 0 .1 0',chain:'M10 23l13-10 13 12-13 13zM23 35l13-10 13 12-13 13zM36 47l13-10 9 9-11 10',star:'M32 8l5 17 19 1-14 12 4 18-14-11-15 11 5-18L8 26l19-1zM32 25v17m-8-8h16'};
function crest(c='star',extra=''){return `<svg class="crest ${extra}" viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="30" fill="none" stroke="currentColor" stroke-width=".8"/><circle cx="32" cy="32" r="27" fill="none" stroke="currentColor" stroke-width=".5"/><g transform="translate(7 7) scale(.78)" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="${paths[c]||paths.star}"/></g></svg>`}
function corners(){return ['tl','tr','br','bl'].map(p=>`<svg class="corner ${p}" viewBox="0 0 60 60" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.2"><path d="M5 55V15Q5 5 15 5h40M12 49V21q0-9 9-9h28M5 35q22 2 20-18Q42 15 42 5M8 25Q-1 8 15 9q13 1 8 12-5 8-11 1m17-9q6 19 17 9 6-9-4-10M12 44q15-2 22-17"/><path d="M15 14q-7 6 0 11 9-6 0-11M32 6q-7 4 0 8 7-4 0-8M7 37q-7 4 0 8 7-4 0-8" fill="currentColor" opacity=".4"/></g></svg>`).join('')}
function frame(number,label){return `<div class="page-border"></div>${corners()}<footer class="folio"><span>${label}</span><span>✧ &nbsp; ${String(number).padStart(2,'0')} &nbsp; ✧</span></footer>`}
function art(c,cls='hero-art'){return `<img class="${cls}" src="${c.heroImage||''}" alt="${esc(c.name)} — ${esc(c.summary.split('.')[0])}." decoding="async" ${cls==='hero-art'?'fetchpriority="high"':'loading="lazy"'}>`}
function fallback(c){return `<div class="fallback-art">${crest(c.emblem)}<p>Primary plate withheld<br>pending preservation.</p><small>${esc(c.name)}</small></div>`}
const cropPoints=[[44,17,40,92],[44,29,30,35],[38,18,23,51],[47,17,66,5],[37,48,89,43],[75,70,47,51],[65,33,29,21],[65,40,53,18],[87,13,28,50],[34,27,85,74],[45,22,74,13],[47,35,66,79],[82,14,84,47],[66,46,24,44],[34,46,60,25],[47,7,60,10],[60,28,35,76],[71,31,36,58],[74,38,39,82],[59,10,29,22]];
function schematic(c){const kind=c.id%5;const shapes=[`<path d="M15 47Q40 3 75 25T136 43Q115 80 73 63T15 47Z"/><path d="M22 46Q50 25 74 42T130 45M26 50Q51 37 75 49T125 51"/><path d="M38 32v24m15-29v34m16-35v36m17-31v33m17-28v25m15-23v16"/>`,`<path d="M15 48Q40 12 130 20L105 65Q55 86 15 48Z"/><path d="M22 48L120 25M36 46l-2-13m14 8 4-16m9 10 12-11m-9 12 5 33m6-39 14 30m-45-14 3 25"/>`,`<path d="M20 55L43 20l30 14 30-16 27 37-28 17-29-12-30 12Z"/><path d="M20 55l53-21 57 21M43 20v52m30-38v26m30-42-1 54M20 55h110"/>`,`<ellipse cx="72" cy="43" rx="48" ry="29"/><ellipse cx="72" cy="43" rx="35" ry="22"/><path d="M26 41q20-27 47 0t45 0M26 49q20-27 47 0t45 0M41 21l13 45m12-48 6 52m17-49-8 46"/>`,`<path d="M24 66Q20 12 67 19T128 56Q102 83 77 63T24 66Z"/><path d="M31 58Q30 24 65 30T117 54M38 58Q39 36 67 41T106 53M50 60Q52 48 69 49T93 54"/>`];return `<svg viewBox="0 0 150 90" aria-hidden="true"><g stroke-width="1.1">${shapes[kind]}</g><path d="M74 17V6h35M111 69v11H86" stroke-dasharray="2 2" stroke-width=".6"/><text x="111" y="9" fill="currentColor" stroke="none" font-size="6">SECTION ${c.roman}</text></svg>`}
function studies(c){const p=cropPoints[c.id-1];return c.anatomyStudies.map((s,i)=>`<figure class="study">${i===1?schematic(c):`<div class="study-crop" style="--crop-x:${p[i===0?0:2]}%;--crop-y:${p[i===0?1:3]}%">${art(c,'detail-art')}</div>`}<figcaption>${String.fromCharCode(97+i)}. ${esc(s)}</figcaption></figure>`).join('')}
function leftPage(c){return `<article class="page left plate-${c.id%3}" style="--accent:${c.palette}" aria-label="${esc(c.name)} illustration page">${frame(c.id*2-1,'PLATE '+c.roman+' · FIELD OBSERVATIONS')}<div class="plate-heading">${crest(c.emblem)}<div><p class="kicker">SPECIMEN ${c.roman} · ${esc(c.epithet)}</p><small>${esc(c.habitat.split(',')[0])} / expedition record</small></div></div><div class="plate-art"><button class="hero-button" data-focus="${c.id}" aria-label="Inspect ${esc(c.name)} illustration">${c.heroImage?art(c):fallback(c)}</button><svg class="annotation-leaders" aria-hidden="true"></svg>${c.annotations.map((a,i)=>{const t=c.callouts[i];return `<div class="annotation a${i}" data-x="${t.x}" data-y="${t.y}" data-lx="${t.lx}" data-ly="${t.ly}">${esc(a)}</div>`}).join('')}</div><div class="measurement"><span>${esc(c.measurement)}</span><span class="scale-line"></span><span>NOT TO SCALE</span></div><div class="studies">${studies(c)}</div><p class="plate-observation">${esc(c.detail)} <span>— V.</span></p></article>`}
function ability(a){return `<div class="ability"><h3>${esc(a[0])}.</h3> ${esc(a[1])}</div>`}
function rightPage(c){return `<article class="page right" style="--accent:${c.palette}" aria-label="${esc(c.name)} field entry">${frame(c.id*2,'THE FIELD CODEX · VOLUME I')}<header class="entry-head"><p class="kicker">${c.roman} · ${esc(c.epithet)}</p><h1>${esc(c.name)}</h1><p class="classification">${esc(c.classification)}</p></header><div class="stats"><div><b>GUARD</b><span>${c.guard}</span></div><div><b>VIGOR</b><span>${c.vigor}</span></div><div><b>PACE</b><span class="pace">${esc(c.pace)}</span></div><div><b>HAZARD</b><span>${romans[c.hazard-1]}</span></div></div><div class="attributes">${['Might','Finesse','Endurance','Reason','Instinct','Presence'].map((a,i)=>`<div><b>${a.toUpperCase()}</b><span>${c.attributes[i]} (${Math.floor((c.attributes[i]-10)/2)>=0?'+':''}${Math.floor((c.attributes[i]-10)/2)})</span></div>`).join('')}</div><div class="entry-copy"><p class="summary">${esc(c.summary)}</p><h2 class="profile-heading">Field profile</h2><div class="field-profile">${[['Resilience',c.resilience],['Trained instincts',c.trainedInstincts],['Senses',c.senses],['Communication',c.communication],['Disposition',c.disposition]].map(a=>`<div><b>${a[0]}.</b> ${esc(a[1])}</div>`).join('')}</div><div class="entry-columns"><div><h2>Adaptations</h2>${c.adaptations.map(ability).join('')}</div><div><h2>Maneuvers</h2>${c.maneuvers.map(ability).join('')}<h2>Reflex</h2>${ability(c.reflex)}<h2>Habitat</h2><p>${esc(c.habitat)}</p></div></div><div class="ecology"><section><h2>Ecology</h2><p>${esc(c.ecology)}</p></section><section><h2>Behavior</h2><p>${esc(c.behavior)}</p></section></div><aside class="v-note"><p>${esc(c.fieldNote)} <span>— V.</span></p><div class="wax" aria-hidden="true">V</div></aside></div></article>`}
function cover(){return `<div class="cover-wrap"><article class="cover">${corners()}<p class="kicker">THE COLLECTED EXPEDITIONS OF V.</p><h1>THE FIELD CODEX<span>of</span>IMPOSSIBLE<br>FAUNA</h1><p class="cover-subtitle">Twenty Anatomies Beyond the Familiar</p><div class="cover-medallion"><svg viewBox="0 0 180 180" aria-hidden="true" style="width:100%;height:100%;position:relative"><g fill="none" stroke="currentColor"><circle cx="90" cy="90" r="80"/><circle cx="90" cy="90" r="73" stroke-dasharray="2 5"/><path d="M90 5v22m0 126v22M5 90h22m126 0h22M31 31l15 15m88 88 15 15M31 149l15-15m88-88 15-15"/><path d="M90 39l12 37 39 14-39 13-12 38-13-38-38-13 38-14z"/><circle cx="90" cy="90" r="24"/><path d="M71 86q18-24 38 0M73 98q17-18 34 0M81 69v42m18-42v42"/></g></svg></div><button class="open-book" id="open-book">OPEN THE CODEX</button><p class="compiler">V. &nbsp; · &nbsp; VOLUME I</p></article></div>`}
function frontPages(){return [`<article class="page left front-page">${frame(0,'THE COLLECTED EXPEDITIONS') }<p class="kicker">FIELD JOURNAL · VOLUME I</p><h1>The Field Codex<small>of</small>Impossible Fauna</h1>${crest('star')}<p class="cover-subtitle">Twenty Anatomies Beyond the Familiar</p><svg class="expedition" viewBox="0 0 280 190" aria-label="A fragmentary expedition chart"><g fill="none" stroke="currentColor"><path d="M25 120l24-34 20 17 32-66 29 40 25-19 48 47 33-22 21 38M36 136q45-23 74 5t127-6M49 150q51-19 86 4t89-5" stroke-width=".8"/><path d="M42 131Q80 72 107 102t53-9 69-40" stroke-dasharray="3 4"/><circle cx="42" cy="131" r="3"/><circle cx="160" cy="93" r="3"/><circle cx="229" cy="53" r="3"/><path d="M245 14v31m-15-15h30m-15-14-4 15 4 13 4-13z"/></g></svg><p class="preface">Drawn in weather, corrected by experience,<br>and bound against better judgment.</p></article>`,`<article class="page right front-page">${frame(0,'A NOTE TO THE READER')}<p class="kicker">BEFORE YOU TURN THE PAGE</p><blockquote><p>These pages are not a taxonomy.<br>Taxonomy implies certainty.</p><p>They record what I approached closely enough to measure, survived long enough to sketch, and learned to fear for the correct reasons.</p></blockquote><span class="signature">V.</span><p class="preface">A word on the figures: roll a twenty-sided die and add the named modifier. Meet a test’s number to succeed; a strike must meet Guard. Harm reduces Vigor. At zero, a creature withdraws or is overcome. A round is roughly six seconds; one maneuver and movement, plus one triggered reflex.</p><p class="preface">Hazard runs from I, a local danger, to VI, an expedition-ending presence. The figures are a language for encounters, never a substitute for observation.</p><button class="start-reading" id="begin-reading">BEGIN THE FIELD RECORD</button></article>`]}
function endPages(){return [`<article class="page left front-page">${frame(41,'EXPEDITION RECORD ENDS')}${crest('star')}<p class="kicker">THE NORTHERN SALT HORIZON</p><blockquote>At dawn, the tracks continued.<br>The notes did not.</blockquote><p class="preface">Twenty specimens recorded.<br>An unknown number still beyond the map.</p></article>`,`<article class="page right front-page">${frame(42,'VOLUME I')}<p class="kicker">END OF VOLUME I</p><p class="plate-observation">Provided, of course, that I return.</p><button class="start-reading" id="return-index">REVISIT THE REGISTER</button></article>`]}
function pages(s){if(s.entry===-1)return frontPages();if(s.entry===20)return endPages();return[leftPage(creatures[s.entry]),rightPage(creatures[s.entry])]}
function markup(s){if(s.entry===-2)return cover();let p=pages(s);return `<div class="spread">${mobile.matches?p[s.side]:p.join('')}<button class="edge prev" aria-label="Turn to previous page"></button><button class="edge next" aria-label="Turn to next page"></button></div>`}
let measuredWidth=0;
function sizeBinding(){
  book.classList.toggle('single-page',mobile.matches);
  if(mobile.matches){book.style.removeProperty('--page-height');measuredWidth=0;return}
  const width=book.clientWidth;
  if(width===measuredWidth)return;
  const measure=document.createElement('div');measure.className='book-measure';
  const bindingStyle=getComputedStyle(book);measure.style.width=(width-parseFloat(bindingStyle.paddingLeft)-parseFloat(bindingStyle.paddingRight))+'px';
  measure.innerHTML=creatures.map(c=>`<div class="spread"><article class="page left"></article>${rightPage(c)}</div>`).join('');
  book.append(measure);
  const height=Math.max(960,...[...measure.querySelectorAll('.spread')].map(p=>p.getBoundingClientRect().height));
  measure.remove();book.style.setProperty('--page-height',Math.ceil(height)+'px');measuredWidth=width;
}
function render(){book.innerHTML=markup(state);sizeBinding();updateControls();wireImages();preload();}
function updateControls(){let c=creatures[state.entry];$('#location').textContent=c?`${c.roman} · ${c.name.toUpperCase()}${mobile.matches?' · '+(state.side+1)+'/2':' · '+String(c.id*2-1).padStart(2,'0')+'—'+String(c.id*2).padStart(2,'0')}`:state.entry===-2?'BOUND IN CURIOSITY':state.entry===-1?'FRONTISPIECE':'END OF VOLUME I';$('#previous').disabled=state.entry===-2||busy;$('#next').disabled=(state.entry===20&&(!mobile.matches||state.side===1))||busy;document.title=c?`${c.name} · The Field Codex`:'The Field Codex of Impossible Fauna';}
function save(){const hash=state.entry>=0&&state.entry<20?'#'+creatures[state.entry].slug:state.entry===-1?'#frontispiece':state.entry===20?'#colophon':'#cover';try{history.replaceState(null,'',hash)}catch{}try{localStorage.setItem('field-codex-v1',JSON.stringify(state))}catch{}}
function turnSurface(page,side,width,height){
  const surface=document.createElement('div');
  surface.className='turn-surface '+side;
  surface.style.width=width+'px';surface.style.height=height+'px';
  const copy=page.cloneNode(true);
  copy.style.width=width+'px';copy.style.height=height+'px';copy.style.minHeight='0';
  copy.querySelectorAll('[id]').forEach(el=>el.removeAttribute('id'));
  surface.append(copy);return surface;
}
async function turnPages(target,forward){
  const single=mobile.matches,spread=book.querySelector('.spread');
  const current=[...spread.querySelectorAll(':scope > .page')];
  const departing=current[single?0:forward?1:0];
  const rect=departing.getBoundingClientRect(),bookRect=book.getBoundingClientRect();
  const holder=document.createElement('div');holder.innerHTML=markup(target);
  const incoming=[...holder.querySelectorAll('.spread > .page')];
  // Decode incoming art before moving the first sheet; a cold image must not flash blank.
  await Promise.all(incoming.flatMap(p=>[...p.querySelectorAll('img')]).map(img=>img.decode().catch(()=>{})));
  const stage=document.createElement('div');stage.className='page-turn '+(single?'single ':'')+(forward?'forward':'backward');
  stage.setAttribute('aria-hidden','true');stage.inert=true;
  stage.style.top=(rect.top-bookRect.top)+'px';stage.style.height=rect.height+'px';
  const front=turnSurface(departing,'turn-front',rect.width,rect.height);
  front.style.left=(rect.left-bookRect.left)+'px';stage.append(front);
  let back;
  if(!single){
    const receiving=current[forward?0:1].getBoundingClientRect();
    back=turnSurface(incoming[forward?0:1],'turn-back',rect.width,rect.height);
    back.style.left=(receiving.left-bookRect.left)+'px';back.style.visibility='hidden';stage.append(back);
  }
  book.append(stage);
  // Keep the stationary old page. Only the page beneath the lifting sheet changes.
  const beneath=incoming[single?0:forward?1:0];
  const oldHeight=spread.getBoundingClientRect().height;
  spread.style.height=oldHeight+'px';spread.style.overflow='hidden';
  current.forEach(p=>{p.style.height=rect.height+'px';p.style.minHeight='0'});
  beneath.style.height=rect.height+'px';beneath.style.minHeight='0';
  departing.replaceWith(beneath);wireImages();
  const duration = 860;
  await new Promise(resolve=>{
    let frame,start;
    const finish=()=>{cancelAnimationFrame(frame);finishTurn=null;resolve()};finishTurn=finish;
    function tick(now){
      if(start===undefined)start=now;
      const progress=Math.min(1,(now-start)/duration);
      const eased=progress*progress*(3-2*progress),angle=180*eased;
      const lift=Math.sin(Math.PI*eased);
      // Each face is a separate composited surface, visible only when facing the reader.
      // Never rely on a flattened preserve-3d container to hide reversed printing.
      front.style.visibility=angle<90?'visible':'hidden';
      front.style.transform=`rotateY(${forward?-angle:angle}deg)`;
      front.style.setProperty('--turn-shade',String(.21*lift));
      front.style.boxShadow=`${(forward?-1:1)*12*lift}px 3px ${22*lift}px rgba(42,24,11,${.22*lift})`;
      if(back){back.style.visibility=angle>=90?'visible':'hidden';back.style.transform=`rotateY(${forward?180-angle:angle-180}deg)`;back.style.setProperty('--turn-shade',String(.16*lift));back.style.boxShadow=`${(forward?-1:1)*8*lift}px 3px ${18*lift}px rgba(42,24,11,${.16*lift})`;}
      if(progress<1)frame=requestAnimationFrame(tick);else finish();
    }
    frame=requestAnimationFrame(tick);
  });
}
async function go(target,animate=true){
  if(busy)return;
  target={entry:Math.max(-2,Math.min(20,target.entry)),side:target.entry===-2?0:Math.max(0,Math.min(1,target.side||0))};
  if(target.entry===state.entry&&target.side===state.side)return;
  const old={...state},forward=target.entry>old.entry||(target.entry===old.entry&&target.side>old.side);
  busy=true;book.setAttribute('aria-busy','true');updateControls();
  const canTurn=animate&&!reduced.matches&&old.entry!==-2&&target.entry!==-2;
  try{if(canTurn)await turnPages(target,forward)}finally{
    state=target;if(!mobile.matches)state.side=0;save();busy=false;render();book.removeAttribute('aria-busy');
  }
  if(!canTurn){book.classList.add('dissolve');setTimeout(()=>book.classList.remove('dissolve'),180)}
  $('#status').textContent=creatures[state.entry]?`${creatures[state.entry].name}, ${mobile.matches?(state.side?'field entry':'specimen plate'):'pages '+(state.entry*2+1)+' and '+(state.entry*2+2)}`:state.entry===-2?'Cover':state.entry===-1?'Frontispiece':'End of volume';
  if(mobile.matches)window.scrollTo({top:0,behavior:'instant'});
}
function next(){if(state.entry===20&&(!mobile.matches||state.side===1))return;if(state.entry===-2)return go({entry:-1,side:0});if(mobile.matches&&state.side===0)return go({...state,side:1});go({entry:state.entry+1,side:0})}
function previous(){if(state.entry===-2)return;if(mobile.matches&&state.side===1)return go({...state,side:0});go({entry:state.entry-1,side:mobile.matches&&state.entry>-1?1:0})}
function drawCallouts(plate){
  const img=plate.querySelector('.hero-art'),svg=plate.querySelector('.annotation-leaders');
  if(!svg)return;
  if(!img?.naturalWidth){svg.innerHTML='';return}
  const w=plate.clientWidth,h=plate.clientHeight;
  if(!w||!h)return;
  const scale=Math.min(img.clientWidth/img.naturalWidth,img.clientHeight/img.naturalHeight);
  const iw=img.naturalWidth*scale,ih=img.naturalHeight*scale;
  const ox=(w-iw)/2,oy=(h-ih)/2;
  svg.setAttribute('viewBox',`0 0 ${w} ${h}`);
  const f=n=>n.toFixed(2);
  svg.innerHTML=[...plate.querySelectorAll('.annotation')].map(note=>{
    const nw=note.offsetWidth,nh=note.offsetHeight;
    const nx=(w-nw)*Number(note.dataset.lx),ny=(h-nh)*Number(note.dataset.ly);
    note.style.left=nx+'px';note.style.top=ny+'px';
    const tx=ox+iw*Number(note.dataset.x),ty=oy+ih*Number(note.dataset.y);
    // Start at the text rectangle's edge nearest the anatomical landmark.
    const cx=nx+nw/2,cy=ny+nh/2,dx=tx-cx,dy=ty-cy;
    const edge=Math.min((nw/2+5)/Math.max(Math.abs(dx),.01),(nh/2+5)/Math.max(Math.abs(dy),.01));
    if(edge>=1)return ''; // Never draw an arrow through its own label.
    const sx=cx+dx*edge,sy=cy+dy*edge,length=Math.hypot(tx-sx,ty-sy);
    const bend=Math.min(18,length*.1)*(Number(note.dataset.lx)>.5?-1:1);
    const qx=(sx+tx)/2-(ty-sy)/length*bend,qy=(sy+ty)/2+(tx-sx)/length*bend;
    const angle=Math.atan2(ty-qy,tx-qx),head=5;
    const d=`M${f(sx)} ${f(sy)}Q${f(qx)} ${f(qy)} ${f(tx)} ${f(ty)}M${f(tx-head*Math.cos(angle-.45))} ${f(ty-head*Math.sin(angle-.45))}L${f(tx)} ${f(ty)}L${f(tx-head*Math.cos(angle+.45))} ${f(ty-head*Math.sin(angle+.45))}`;
    return `<path class="leader-halo" d="${d}"/><path class="leader" data-target-x="${f(tx)}" data-target-y="${f(ty)}" d="${d}"/>`;
  }).join('');
}
const calloutObserver=new ResizeObserver(items=>items.forEach(item=>drawCallouts(item.target)));
function wireImages(){
  calloutObserver.disconnect();
  document.querySelectorAll('#book .plate-art').forEach(plate=>{calloutObserver.observe(plate);drawCallouts(plate)});
  document.querySelectorAll('#book img, #focus-dialog img').forEach(img=>{
    img.onload=()=>{const plate=img.closest('.plate-art');if(plate)drawCallouts(plate)};
    img.onerror=()=>{
      const plate=img.closest('.plate-art');
      if(img.classList.contains('hero-art'))img.replaceWith(Object.assign(document.createElement('div'),{innerHTML:fallback(creatures[state.entry]||creatures[0])}));else img.style.display='none';
      if(plate){plate.querySelector('.annotation-leaders')?.replaceChildren();plate.querySelectorAll('.annotation').forEach(n=>n.hidden=true)}
    };
    if(img.complete&&img.naturalWidth===0&&img.getAttribute('src'))img.onerror();
  });
}
function preload(){[state.entry-1,state.entry+1].forEach(i=>{if(creatures[i]?.heroImage){const im=new Image;im.src=creatures[i].heroImage}})}
function openIndex(){$('#index-dialog').showModal()}
function notice(text){$('#status').textContent=text;$('#status').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#status').classList.remove('visible'),3500)}
$('#toc').innerHTML=creatures.map(c=>`<button data-entry="${c.id-1}">${crest(c.emblem)}<span><small>SPECIMEN ${c.roman}</small>${esc(c.name)}</span><span class="toc-number">${String(c.id*2-1).padStart(2,'0')}</span></button>`).join('');
$('#previous').onclick=previous;$('#next').onclick=next;$('#location').onclick=openIndex;$('#index-button').onclick=openIndex;$('#cover-link').onclick=()=>{$('#index-dialog').close();go({entry:-2,side:0})};
document.addEventListener('click',e=>{const t=e.target.closest('button');if(!t)return;if(t.classList.contains('close'))t.closest('dialog').close();if(t.matches('.edge.next'))next();if(t.matches('.edge.prev'))previous();if(t.id==='open-book')go({entry:-1,side:0});if(t.id==='begin-reading')go({entry:0,side:0});if(t.id==='return-index')openIndex();if(t.dataset.entry!==undefined){$('#index-dialog').close();go({entry:Number(t.dataset.entry),side:0})}if(t.dataset.focus){let c=creatures[Number(t.dataset.focus)-1];$('#focus-content').innerHTML=`<h2>${esc(c.name)}</h2>${c.heroImage?art(c):fallback(c)}<p>${esc(c.measurement)} · ${esc(c.anatomyStudies.join(' / '))}</p>`;$('#focus-dialog').showModal()}});
document.addEventListener('keydown',e=>{if(document.querySelector('dialog[open]')||e.altKey||e.ctrlKey||e.metaKey||/INPUT|TEXTAREA|SELECT/.test(e.target.tagName))return;if(['ArrowRight','PageDown','ArrowLeft','PageUp','Home','End'].includes(e.key))e.preventDefault();if(['ArrowRight','PageDown'].includes(e.key))next();if(['ArrowLeft','PageUp'].includes(e.key))previous();if(e.key==='Home')go({entry:-2,side:0});if(e.key==='End')go({entry:19,side:0})});
book.addEventListener('touchstart',e=>{if(e.touches.length===1)touch={x:e.touches[0].clientX,y:e.touches[0].clientY};else touch=null},{passive:true});book.addEventListener('touchend',e=>{if(!touch)return;const dx=e.changedTouches[0].clientX-touch.x,dy=e.changedTouches[0].clientY-touch.y;touch=null;if(Math.abs(dx)>65&&Math.abs(dx)>Math.abs(dy)*1.6){if(dx<0)next();else previous()}},{passive:true});
$('#share-button').onclick=async()=>{const c=creatures[state.entry],title=c?c.name+' · The Field Codex':'The Field Codex of Impossible Fauna',url=location.href;try{if(navigator.share&&location.protocol!=='file:'){await navigator.share({title,url});return}if(navigator.clipboard&&location.protocol!=='file:'){await navigator.clipboard.writeText(url);notice('Link copied to your clipboard.');return}}catch(e){if(e.name==='AbortError')return}$('#focus-content').innerHTML=`<h2>Share this field record</h2><p>${esc(title)}</p><p>${location.protocol==='file:'?'Send the bestiary.html file to share the whole book.':'Copy the address below.'}</p><input aria-label="Current entry address" readonly value="${esc(url)}" style="width:100%;padding:12px;background:#fff8e7;color:#38291e;border:1px solid #96733c">`;$('#focus-dialog').showModal();$('#focus-content input').select()};
if(!document.fullscreenEnabled)$('#fullscreen-button').hidden=true;else $('#fullscreen-button').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen()}catch{notice('Fullscreen is unavailable in this browser.')}};
document.addEventListener('fullscreenchange',()=>$('#fullscreen-button').setAttribute('aria-label',document.fullscreenElement?'Exit fullscreen':'Enter fullscreen'));
function fromHash(){let hash;try{hash=decodeURIComponent(location.hash.slice(1))}catch{return null}const i=creatures.findIndex(c=>c.slug===hash);if(i>=0)return{entry:i,side:0};if(hash==='frontispiece')return{entry:-1,side:0};if(hash==='colophon')return{entry:20,side:0};if(hash==='cover')return{entry:-2,side:0};return null}
window.addEventListener('hashchange',()=>{const target=fromHash();if(target){if(busy){finishTurn?.();setTimeout(()=>go(target,false),0)}else go(target,false)}});mobile.addEventListener('change',()=>{if(busy){finishTurn?.();return}if(!mobile.matches)state.side=0;render()});
let resizeFrame;window.addEventListener('resize',()=>{if(busy)finishTurn?.();cancelAnimationFrame(resizeFrame);resizeFrame=requestAnimationFrame(()=>{if(!busy)render()})});
window.addEventListener('beforeprint',()=>{$('#print-book').innerHTML=frontPages().join('')+creatures.map(c=>leftPage(c)+rightPage(c)).join('')+endPages().join('');$('#print-book').querySelectorAll('.plate-art').forEach(plate=>{calloutObserver.observe(plate);drawCallouts(plate);const img=plate.querySelector('.hero-art');if(img)img.onload=()=>drawCallouts(plate)})});window.addEventListener('afterprint',()=>{$('#print-book').innerHTML='';wireImages()});
let initial=fromHash();if(!initial){try{const stored=JSON.parse(localStorage.getItem('field-codex-v1'));if(stored&&Number.isInteger(stored.entry)&&stored.entry>=-2&&stored.entry<=20&&[0,1].includes(stored.side))initial=stored}catch{}}state=initial||state;if(!mobile.matches)state.side=0;render();




